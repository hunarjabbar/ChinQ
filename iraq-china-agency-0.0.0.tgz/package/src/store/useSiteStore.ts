import { create } from 'zustand';
import { persist } from 'zustand/middleware';

export interface SocialLinksConfig {
  whatsapp: string;
  facebook: string;
  instagram: string;
  linkedin: string;
  weibo: string;
  wechat: string;
  youtube: string;
  x: string;
}

export interface SiteConfig {
  siteName: string;
  contactEmail: string;
  cachingEnabled: boolean;
  autoTranslate: boolean;
  geoLatencyRoute: string;
  systemMaintenance: boolean;
  brandColor: string;
  inkColor: string;
  paperColor: string;
  socialLinks: SocialLinksConfig;
}

interface SiteStore extends SiteConfig {
  updateSettings: (settings: Partial<SiteConfig>) => void;
}

export const useSiteStore = create<SiteStore>()(
  persist(
    (set) => ({
      siteName: 'Iraq - China Agency',
      contactEmail: 'desk@iraqchinaagency.com',
      cachingEnabled: true,
      autoTranslate: true,
      geoLatencyRoute: 'baghdad-beijing',
      systemMaintenance: false,
      brandColor: '#c91c24',
      inkColor: '#1A1A1A',
      paperColor: '#FAFAFA',
      socialLinks: {
        whatsapp: 'https://chat.whatsapp.com/IraqChinaAgencyOfficial',
        facebook: 'https://facebook.com/IraqChinaAgency',
        instagram: 'https://instagram.com/iraqchinaagency',
        linkedin: 'https://linkedin.com/company/iraq-china-agency',
        weibo: 'https://weibo.com/iraqchinaagency',
        wechat: 'IraqChinaAgency_Official',
        youtube: 'https://youtube.com/@IraqChinaAgency',
        x: 'https://x.com/IraqChinaAgency',
      },
      updateSettings: (newSettings) => set((state) => ({ ...state, ...newSettings })),
    }),
    {
      name: 'site-config-storage',
    }
  )
);
