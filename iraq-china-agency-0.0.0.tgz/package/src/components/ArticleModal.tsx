import React from 'react';
import { Article, Locale } from '../types';
import { ArticleDetail } from './ArticleDetail';

interface ArticleModalProps {
  article: Article;
  lang: Locale;
  onClose: () => void;
}

export function ArticleModal({ article, lang, onClose }: ArticleModalProps) {
  return (
    <div 
      className="fixed inset-0 bg-brand-800/75 backdrop-blur-md flex items-center justify-center z-50 p-4 sm:p-6 md:p-8"
      onClick={onClose}
    >
      <div 
        className="bg-paper-50 border-x border-brand-800 max-w-4xl w-full h-[90vh] overflow-y-auto shadow-2xl flex flex-col relative text-start transition-all duration-300"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header toolbar */}
        <div className="px-6 py-4 bg-white border-b border-brand-800/10 flex justify-end items-center shrink-0 sticky top-0 z-20">
          <button 
            onClick={onClose}
            className="text-ink-900 hover:text-brand-800 font-black text-xs uppercase tracking-widest border border-brand-800/20 px-3 py-1 hover:border-brand-800 transition-colors cursor-pointer bg-white"
          >
            {lang === 'ar' ? '✕ إغلاق' : lang === 'ckb' ? '✕ داخستن' : lang === 'zh' ? '✕ 关闭' : '✕ Close'}
          </button>
        </div>

        <ArticleDetail article={article} lang={lang} />
      </div>
    </div>
  );
}
