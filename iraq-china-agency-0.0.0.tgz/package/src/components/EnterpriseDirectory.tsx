import React from 'react';
import { Locale } from '../types';
// from 'react';

import { Building2, CheckCircle2 } from 'lucide-react';

export default function EnterpriseDirectory({ lang }: { lang: Locale }) {
  const title = lang === 'zh' ? '认证企业与供应商名录' : 'Verified Enterprise & Supplier Directory';
  
  const enterprises = [
    {
      id: 1,
      name: 'PowerChina',
      sector: 'Energy & Infrastructure',
      verified: true
    },
    {
      id: 2,
      name: 'Huawei Technologies Iraq',
      sector: 'Telecommunications',
      verified: true
    },
    {
      id: 3,
      name: 'ZPEC (Zhongman Petroleum)',
      sector: 'Oil & Gas Services',
      verified: true
    },
    {
      id: 4,
      name: 'CSCEC Middle East',
      sector: 'Construction',
      verified: true
    }
  ];

  return (
    <section id="directory" className="py-24 bg-white">
      <div className="w-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center mb-12">
          <Building2 className="w-6 h-6 mr-3 text-brand-800" />
          <h2 className="text-2xl font-serif font-bold text-ink-900">{title}</h2>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {enterprises.map((e) => (
            <div key={e.id} className="p-6 border border-[#EAEAEE] hover:border-brand-800 transition-colors">
              <div className="flex justify-between items-start mb-4">
                <h3 className="font-bold text-ink-900">{e.name}</h3>
                {e.verified && <CheckCircle2 className="w-5 h-5 text-green-600" />}
              </div>
              <div className="text-sm text-gray-500 uppercase tracking-wider">{e.sector}</div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
