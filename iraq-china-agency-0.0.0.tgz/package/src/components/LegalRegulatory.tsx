import React from 'react';
import { Locale } from '../types';
// from 'react';

import { FileText } from 'lucide-react';

export default function LegalRegulatory({ lang }: { lang: Locale }) {
  const title = lang === 'zh' ? '法律与监管合规资讯' : 'Legal & Regulatory Intelligence Desk';
  
  const updates = [
    {
      id: 1,
      title: lang === 'zh' ? '伊拉克新外资所有权法规解读' : 'Analysis of New Foreign Ownership Regulations in Iraq',
      date: '2026-08-20',
      category: 'Foreign Direct Investment'
    },
    {
      id: 2,
      title: lang === 'zh' ? '中伊双重征税豁免协定细节' : 'Details of Sino-Iraqi Double Taxation Exemption Agreement',
      date: '2026-08-15',
      category: 'Taxation'
    },
    {
      id: 3,
      title: lang === 'zh' ? '库尔德斯坦地区油气合同法更新' : 'Kurdistan Region Oil & Gas Contract Law Updates',
      date: '2026-08-10',
      category: 'Energy Law'
    }
  ];

  return (
    <section id="legal" className="py-24 bg-[#F9F9F9]">
      <div className="w-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center mb-12">
          <FileText className="w-6 h-6 mr-3 text-brand-800" />
          <h2 className="text-2xl font-serif font-bold text-ink-900">{title}</h2>
        </div>
        <div className="space-y-4">
          {updates.map((u) => (
            <div key={u.id} className="bg-white p-6 border border-[#E5E5E5] flex flex-col md:flex-row justify-between items-start md:items-center hover:bg-gray-50 transition-colors cursor-pointer">
              <div>
                <div className="text-xs font-semibold text-gray-500 mb-1">{u.category}</div>
                <h3 className="text-lg font-bold text-ink-900">{u.title}</h3>
              </div>
              <div className="mt-4 md:mt-0 text-sm font-mono text-gray-400">
                {u.date}
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
