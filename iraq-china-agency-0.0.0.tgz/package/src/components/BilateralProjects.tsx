import React from 'react';
import { Locale } from '../types';
// from 'react';


export default function BilateralProjects({ lang }: { lang: Locale }) {

  const title = lang === 'ar' ? 'مشاريع البنية التحتية الثنائية' : lang === 'zh' ? '双边基础设施项目跟踪' : lang === 'ckb' ? 'پڕۆژە دووقۆڵییەکانی ژێرخانی ئابووری' : 'Bilateral Projects & Infrastructure Pipeline';

  const projects = [
    {
      id: 1,
      name: lang === 'zh' ? '法奥大港' : 'Al Faw Grand Port',
      status: lang === 'zh' ? '建设中' : 'Under Construction',
      value: '$2.6B',
      desc: lang === 'zh' ? '连接波斯湾的超级港口项目。' : 'Mega-port project connecting the Persian Gulf.'
    },
    {
      id: 2,
      name: lang === 'zh' ? '发展路项目' : 'Development Road',
      status: lang === 'zh' ? '规划中' : 'Planning',
      value: '$17B',
      desc: lang === 'zh' ? '通过土耳其连接伊拉克和欧洲的铁路网络。' : 'Rail network linking Iraq to Europe via Turkey.'
    },
    {
      id: 3,
      name: lang === 'zh' ? '纳西里耶国际机场' : 'Nasiriyah International Airport',
      status: lang === 'zh' ? '建设中' : 'Under Construction',
      value: '$367M',
      desc: lang === 'zh' ? '中国建筑集团承建的现代化机场。' : 'Modern airport constructed by CSCEC.'
    }
  ];

  return (
    <section id="projects" className="py-24 bg-white border-y border-[#F5F5F5]">
      <div className="w-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <h2 className="text-2xl font-serif font-bold text-ink-900 mb-12">{title}</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {projects.map((p) => (
            <div key={p.id} className="border border-[#E5E5E5] p-6 hover:shadow-sm hover:shadow-md transition-shadow duration-300">
              <div className="text-xs font-bold uppercase text-brand-600 mb-2">{p.status}</div>
              <h3 className="text-xl font-bold text-ink-900 mb-2">{p.name}</h3>
              <div className="text-2xl font-serif text-ink-900 mb-4">{p.value}</div>
              <p className="text-sm text-gray-500">{p.desc}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
