import React from 'react';
import { Locale } from '../types';
// from 'react';


export default function DiplomaticVoices({ lang }: { lang: Locale }) {
  const title = lang === 'zh' ? '高管与外交官之声' : 'Executive & Diplomatic Voices Spotlight';
  
  const voices = [
    {
      id: 1,
      name: 'Ambassador Cui Wei',
      role: 'Chinese Ambassador to Iraq',
      quote: lang === 'zh' ? '“中伊战略伙伴关系正迈入互信与共建的新黄金时代。”' : '"The Sino-Iraqi strategic partnership is entering a new golden era of mutual trust and joint construction."',
      image: 'https://images.unsplash.com/photo-1541872703-74c5e44368f9?auto=format&fit=crop&q=80&w=400'
    },
    {
      id: 2,
      name: 'Dr. Ihsan Al-Shammari',
      role: 'Head of Political Thinking Center',
      quote: lang === 'zh' ? '“伊拉克的复兴需要平衡且建设性的多边合作。”' : '"The reconstruction of Iraq requires balanced, constructive, and multilateral cooperation."',
      image: 'https://images.unsplash.com/photo-1556157382-97eda2d62296?auto=format&fit=crop&q=80&w=400'
    }
  ];

  return (
    <section id="diplomatic" className="py-24 bg-brand-800 text-white">
      <div className="w-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <h2 className="text-2xl font-serif font-bold text-white mb-12 border-b border-gray-800 pb-4">{title}</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
          {voices.map((v) => (
            <div key={v.id} className="flex flex-col sm:flex-row gap-6 items-center sm:items-start">
              <img src={v.image} alt={v.name} className="w-24 h-24 rounded-full object-cover grayscale border-2 border-gray-700" />
              <div>
                <p className="text-lg font-serif italic text-gray-300 mb-4">{v.quote}</p>
                <div className="text-sm font-bold text-white">{v.name}</div>
                <div className="text-xs text-gray-400">{v.role}</div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
