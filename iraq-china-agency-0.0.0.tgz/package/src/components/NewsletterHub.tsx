import React, { useState } from 'react';
import { Locale } from '../types';
//, { useState } from 'react';

import { Mail, ArrowRight } from 'lucide-react';

export default function NewsletterHub({ lang }: { lang: Locale }) {
  const [email, setEmail] = useState('');
  const [status, setStatus] = useState<'idle' | 'loading' | 'success' | 'error'>('idle');
  const [message, setMessage] = useState('');

  const title = lang === 'zh' ? '高管晨报与通讯中心' : 'Executive Morning Briefing & Newsletter Hub';
  const desc = lang === 'zh' ? '订阅我们的独家每日简报，获取最新的双边政策与市场动态。' : 'Subscribe to our exclusive daily briefing for the latest bilateral policy and market dynamics.';
  const placeholder = lang === 'zh' ? '您的企业邮箱' : 'Your corporate email address';
  const btnText = lang === 'zh' ? '订阅' : 'Subscribe';

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email) return;
    setStatus('loading');
    
    try {
      const res = await fetch('/api/newsletter/subscribe', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email })
      });
      const data = await res.json();
      
      if (res.ok) {
        setStatus('success');
        setMessage(lang === 'zh' ? '订阅成功！' : 'Successfully subscribed!');
        setEmail('');
      } else {
        setStatus('error');
        setMessage(data.error || 'Failed to subscribe');
      }
    } catch (err) {
      setStatus('error');
      setMessage('Network error. Please try again later.');
    }
  };

  return (
    <section id="newsletter" className="py-20 bg-[#F4F4F4] border-t border-[#E5E5E5]">
      <div className="w-full max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
        <Mail className="w-10 h-10 mx-auto text-brand-800 mb-6" />
        <h2 className="text-3xl font-serif font-black text-ink-900 mb-4">{title}</h2>
        <p className="text-lg text-gray-500 mb-12">{desc}</p>
        
        <form onSubmit={handleSubmit} className="flex flex-col sm:flex-row max-w-lg mx-auto gap-2">
          <input
            type="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            placeholder={placeholder}
            disabled={status === 'loading'}
            className="flex-1 px-4 py-3 border border-[#CCCCCC] focus:outline-none focus:border-brand-800 disabled:bg-gray-100"
            required
          />
          <button
            type="submit"
            disabled={status === 'loading'}
            className="px-6 py-3 bg-[#B02A2A] text-white font-bold tracking-widest uppercase hover:bg-[#8A2020] transition-colors disabled:opacity-50 flex items-center justify-center"
          >
            {status === 'loading' ? '...' : <>{btnText} <ArrowRight className="w-4 h-4 ml-2" /></>}
          </button>
        </form>
        {message && (
          <p className={`mt-4 text-sm font-medium ${status === 'success' ? 'text-green-700' : 'text-brand-600'}`}>
            {message}
          </p>
        )}
      </div>
    </section>
  );
}
