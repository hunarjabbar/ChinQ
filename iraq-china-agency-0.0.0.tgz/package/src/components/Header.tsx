import { Locale, Article } from '../types';
import { useI18n } from '../hooks/useI18n';
import { Link, useNavigate } from 'react-router-dom';
import React, { useState } from 'react';
import { Search, LogIn } from 'lucide-react';
import { useQuery } from '@tanstack/react-query';
import { LanguageSwitcher } from './LanguageSwitcher';
import { SocialHeaderBar } from './SocialLinks';
import { motion } from 'motion/react';
import { useSiteStore } from '../store/useSiteStore';

export function Header({ lang }: { lang: Locale }) {
  const siteName = useSiteStore(state => state.siteName);
  const [searchQuery, setSearchQuery] = useState('');
  const navigate = useNavigate();
  const { t } = useI18n(lang);
  
  const { data: articles = [] } = useQuery<Article[]>({
    queryKey: ['articles'],
    queryFn: async () => {
      const res = await fetch('/api/articles');
      if (!res.ok) throw new Error('Network response was not ok');
      return res.json();
    }
  });

  const breakingNews = articles.slice(0, 5); // Grab latest 5 for the ticker

  const getTranslation = (article: Article) => {
    return article.translations.find(tr => tr.lang === lang) || 
           article.translations.find(tr => tr.lang === 'en') || 
           article.translations[0];
  };

  return (
    <div className="max-w-[1024px] mx-auto w-full relative z-40">
      {/* Main Masthead - NO overflow-hidden on main header container so controls are never clipped */}
      <motion.header initial={{ y: -50, opacity: 0 }} animate={{ y: 0, opacity: 1 }} transition={{ duration: 0.5, ease: "easeOut" }} className="relative flex flex-col items-center pt-6 pb-4 border-b-4 border-brand-800 bg-white/75 backdrop-blur-xl shadow-inner z-50">
        {/* Pulsing red glaring circles underneath - overflow-hidden strictly isolated to background div */}
        <div className="absolute inset-0 pointer-events-none overflow-hidden z-0">
          {/* Small top-left red accent */}
          <div className="absolute top-2 left-6 w-16 h-16 bg-brand-600/35 rounded-full blur-xl animate-pulse" />
          {/* Compact top-right red circle */}
          <div className="absolute top-3 right-10 w-12 h-12 bg-brand-800/40 rounded-full blur-lg animate-pulse [animation-duration:3s]" />
          {/* Small bottom-left circle */}
          <div className="absolute bottom-2 left-1/4 w-20 h-20 bg-brand-700/30 rounded-full blur-xl animate-pulse [animation-duration:4s]" />
          {/* Subtle focal dot */}
          <div className="absolute top-1/2 left-1/12 -translate-y-1/2 w-8 h-8 bg-brand-500/50 rounded-full blur-md animate-pulse [animation-duration:2s]" />
          {/* Compact bottom-right accent */}
          <div className="absolute bottom-1 right-12 w-14 h-14 bg-brand-950/35 rounded-full blur-lg animate-pulse [animation-duration:3.5s]" />
          {/* Tiny center-below glow */}
          <div className="absolute bottom-1 left-1/2 -translate-x-1/2 w-16 h-16 bg-brand-500/25 rounded-full blur-xl animate-pulse [animation-duration:2.5s]" />
        </div>

        <div className="relative z-10 flex flex-col items-center w-full px-4 sm:px-6">
          <div className="text-[11px] font-black uppercase tracking-[0.355em] text-ink-900 text-center mb-2.5 bg-brand-800/5 px-4 py-1 rounded-full border border-brand-800/10">
            The Bridge Between China and Iraq
          </div>

          <div className="relative inline-flex flex-col md:flex-row items-center justify-center my-2.5 gap-3 md:gap-0">
            <Link to={`/${lang}`} className="group">
              <h1 className="text-5xl md:text-6xl lg:text-7xl font-serif font-black tracking-tight mb-1 text-brand-800 group-hover:text-brand-900 drop-shadow-[0_2px_12px_rgba(201,28,36,0.3)] transition-all duration-300 leading-none text-center m-0">
                {siteName.toUpperCase()}
              </h1>
            </Link>
            
            {/* Language Switcher positioned to the side */}
            <div className="md:absolute md:left-full rtl:md:left-auto rtl:md:right-full md:top-1/2 md:-translate-y-1/2 md:ml-6 rtl:md:ml-0 rtl:md:mr-6 flex items-center shrink-0">
              <LanguageSwitcher lang={lang} />
            </div>
          </div>


          <div className="w-full max-w-md mt-4 relative">
            <form onSubmit={(e) => {
              e.preventDefault();
              if (searchQuery.trim()) {
                navigate(`/${lang}/search?q=${encodeURIComponent(searchQuery)}`);
              }
            }}>
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder={lang === 'zh' ? "搜索企业和基建项目..." : "Search enterprise directory and infrastructure projects..."}
                className="w-full pl-10 pr-4 py-2.5 border border-brand-800/30 rounded-md bg-white/70 focus:bg-white focus:outline-none focus:ring-2 focus:ring-brand-800/20 focus:border-brand-800 text-sm text-ink-900 shadow-xs transition-all duration-200"
              />
              <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-brand-800/70" />
            </form>
          </div>

          <div className="w-full flex flex-wrap justify-between items-center px-2 text-[10px] uppercase font-black tracking-widest mt-2 text-ink-900 border-t border-brand-800/15 pt-2 gap-2">
            <span>VOL. CLXII NO. 402</span>
            <span>{new Date().toLocaleDateString(lang === 'ar' ? 'ar-EG' : lang === 'zh' ? 'zh-CN' : 'en-US', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}</span>
            <SocialHeaderBar lang={lang} />
            <span>Price: 15 CNY / 2500 IQD</span>
          </div>
        </div>
      </motion.header>

      {/* Navigation / Breaking News Ticker */}
      <nav className="h-12 border-b border-brand-800 flex items-center bg-paper-50 overflow-hidden relative">
        <div className="absolute left-0 rtl:left-auto rtl:right-0 top-0 bottom-0 z-10 flex items-center px-4 bg-brand-800/85 backdrop-blur-md border-r rtl:border-r-0 rtl:border-l border-white/20 text-white text-xs font-black uppercase tracking-widest animate-liquid-glass-pulse">
          {lang === 'ar' ? 'عاجل' : lang === 'zh' ? '突发新闻' : lang === 'ckb' ? 'هەواڵی بەپەلە' : 'BREAKING'}
        </div>
        <div className="flex-1 overflow-hidden ml-32 rtl:ml-0 rtl:mr-32">
          <div className="flex whitespace-nowrap animate-marquee rtl:animate-marquee-rtl items-center h-full">
            {breakingNews.length > 0 ? breakingNews.map((article, i) => {
              const translation = getTranslation(article);
              return (
                <span key={article.id} className="inline-flex items-center mx-4 text-xs font-bold uppercase tracking-wide">
                  <span className="w-1.5 h-1.5 bg-brand-800 rounded-full mx-3"></span>
                  <Link to={`/${lang}`} className="hover:text-brand-800 transition-colors cursor-pointer">
                    {translation?.title || 'NEWS UPDATE'}
                  </Link>
                </span>
              );
            }) : (
              <span className="inline-flex items-center mx-4 text-xs font-bold uppercase tracking-wide text-gray-500">
                LOADING LATEST DISPATCHES...
              </span>
            )}
          </div>
        </div>
        <div className="absolute right-0 rtl:right-auto rtl:left-0 top-0 bottom-0 z-10 flex items-center px-4 bg-paper-50 border-l rtl:border-l-0 rtl:border-r border-brand-800/20 gap-3 sm:gap-4">
           <Link to={`/${lang}/women`} className="text-[12px] sm:text-[13px] font-sans font-bold uppercase tracking-wider hover:text-brand-800 text-ink-900 transition-colors flex items-center gap-1">
             <span className="text-brand-800">👩‍💼</span> {t('women')}
           </Link>
           <Link to={`/${lang}/tourism`} className="text-[12px] sm:text-[13px] font-sans font-bold uppercase tracking-wider hover:text-brand-800 text-ink-900 transition-colors flex items-center gap-1">
             <span className="text-brand-800">✈️</span> {t('tourism')}
           </Link>

           <Link to={`/${lang}/books`} className="text-[12px] sm:text-[13px] font-sans font-bold uppercase tracking-wider hover:text-brand-800 text-ink-900 transition-colors flex items-center gap-1">
             <span className="text-brand-800">📚</span> {t('books')}
           </Link>
           <a href={`/${lang}#projects`} className="text-[12px] sm:text-[13px] font-sans font-bold uppercase tracking-wider hover:text-brand-800 text-ink-900 transition-colors hidden xl:flex items-center gap-1">
             <span className="text-brand-800">🏗️</span> {t('projects')}
           </a>
           <a href={`/${lang}#legal`} className="text-[12px] sm:text-[13px] font-sans font-bold uppercase tracking-wider hover:text-brand-800 text-ink-900 transition-colors hidden xl:flex items-center gap-1">
             <span className="text-brand-800">⚖️</span> {t('legal')}
           </a>
           <a href={`/${lang}#directory`} className="text-[12px] sm:text-[13px] font-sans font-bold uppercase tracking-wider hover:text-brand-800 text-ink-900 transition-colors hidden xl:flex items-center gap-1">
             <span className="text-brand-800">🏢</span> {t('directory')}
           </a>

           <Link to={`/${lang}/podcasts`} className="text-[12px] sm:text-[13px] font-sans font-bold uppercase tracking-wider hover:text-brand-800 text-ink-900 transition-colors flex items-center gap-1">
             <span className="text-brand-800">🎙️</span> {t('podcasts')}
           </Link>
           <Link to={`/${lang}/live`} className="text-[12px] font-sans font-bold uppercase tracking-wider hover:text-brand-800 text-brand-800 transition-colors flex items-center gap-1.5"><span className="w-2 h-2 bg-brand-800 rounded-full animate-pulse"></span> {t('live')}</Link>
           <Link to={`/${lang}/admin`} className="px-2.5 py-1 text-[11px] font-sans font-bold uppercase tracking-wider text-ink-900 hover:text-white border border-brand-800/30 rounded hover:border-brand-800 hover:bg-brand-700 transition-all flex items-center gap-1 shadow-2xs">
             <LogIn className="w-3 h-3 text-brand-800 group-hover:text-white" />
             {t('signIn')}
           </Link>
        </div>
      </nav>
    </div>
  );
}
