/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { createBrowserRouter, RouterProvider, Navigate, useParams, Outlet, useLocation } from 'react-router-dom';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { useEffect } from 'react';
import { Layout } from './components/Layout';
import { AdminLayout } from './components/AdminLayout';
import { Home } from './pages/Home';
import { ArticlePage } from './pages/ArticlePage';
import { CategoryPage } from './pages/CategoryPage';
import { AdminDashboard } from './pages/AdminDashboard';
import { NotFound } from './pages/NotFound';
import { ErrorBoundary } from './components/ErrorBoundary';
import { LiveEventPage } from './pages/LiveEventPage';
import { LivePortal } from './pages/LivePortal';
import SearchPage from './pages/SearchPage';

import { AdminArticles } from './pages/AdminArticles';
import { AdminArticleNew } from './pages/AdminArticleNew';
import { AdminUsers } from './pages/AdminUsers';
import { AdminMedia } from './pages/AdminMedia';
import { AdminSettings } from './pages/AdminSettings';

import { About } from './pages/About';
import { JoinUs } from './pages/JoinUs';
import { BooksPage } from './pages/BooksPage';
import { AdminBooks } from './pages/AdminBooks';
import { TourismPage } from './pages/TourismPage';
import { AdminTourism } from './pages/AdminTourism';
import { WomenPage } from './pages/WomenPage';
import { AdminWomen } from './pages/AdminWomen';
import { VisaFlightPage } from './pages/VisaFlightPage';
import { AdminVisaFlight } from './pages/AdminVisaFlight';
import PodcastsPage from './pages/PodcastsPage';
import AdminPodcasts from './pages/AdminPodcasts';
import AdminLiveEvents from './pages/AdminLiveEvents';
import { AdminMarketData } from './pages/AdminMarketData';
import { useSiteStore } from './store/useSiteStore';

const queryClient = new QueryClient();

function ThemeApplier() {
  const { brandColor, inkColor, paperColor } = useSiteStore();
  
  useEffect(() => {
    const root = document.documentElement;
    if (brandColor) {
      root.style.setProperty('--color-brand-950', `color-mix(in srgb, ${brandColor} 40%, black)`);
      root.style.setProperty('--color-brand-900', `color-mix(in srgb, ${brandColor} 70%, black)`);
      root.style.setProperty('--color-brand-800', brandColor);
      root.style.setProperty('--color-brand-700', `color-mix(in srgb, ${brandColor} 85%, white)`);
      root.style.setProperty('--color-brand-600', `color-mix(in srgb, ${brandColor} 70%, white)`);
      root.style.setProperty('--color-brand-500', `color-mix(in srgb, ${brandColor} 50%, white)`);
      root.style.setProperty('--color-brand-400', `color-mix(in srgb, ${brandColor} 30%, white)`);
      root.style.setProperty('--color-brand-300', `color-mix(in srgb, ${brandColor} 20%, white)`);
      root.style.setProperty('--color-brand-200', `color-mix(in srgb, ${brandColor} 12%, white)`);
      root.style.setProperty('--color-brand-100', `color-mix(in srgb, ${brandColor} 8%, white)`);
      root.style.setProperty('--color-brand-50', `color-mix(in srgb, ${brandColor} 4%, white)`);
    }
    if (inkColor) {
      root.style.setProperty('--color-ink-900', inkColor);
    }
    if (paperColor) {
      root.style.setProperty('--color-paper-50', paperColor);
    }
  }, [brandColor, inkColor, paperColor]);
  
  return null;
}



function SearchWrapper() {
  const { lang } = useParams<{ lang: string }>();
  const location = useLocation();
  return <SearchPage lang={(lang as any) || 'en'} />;
}

function LangWrapper() {
  const { lang } = useParams<{ lang: string }>();
  const location = useLocation();
  
  useEffect(() => {
    document.documentElement.lang = lang || 'en';
    if (lang === 'ar' || lang === 'ckb') {
      document.documentElement.dir = 'rtl';
    } else {
      document.documentElement.dir = 'ltr';
    }
  }, [lang]);

  if (!['en', 'ar', 'zh', 'ckb'].includes(lang || '')) {
    return <Navigate to="/en" replace />;
  }

  return (
    <Layout lang={lang as 'en' | 'ar' | 'zh' | 'ckb'}>
      <ErrorBoundary key={location.key} lang={lang}>
        <Outlet />
      </ErrorBoundary>
    </Layout>
  );
}

function AdminLangWrapper() {
  const { lang } = useParams<{ lang: string }>();
  const location = useLocation();
  
  useEffect(() => {
    document.documentElement.lang = lang || 'en';
    if (lang === 'ar' || lang === 'ckb') {
      document.documentElement.dir = 'rtl';
    } else {
      document.documentElement.dir = 'ltr';
    }
  }, [lang]);

  if (!['en', 'ar', 'zh', 'ckb'].includes(lang || '')) {
    return <Navigate to="/en/admin" replace />;
  }

  return (
    <ErrorBoundary key={location.key} lang={lang}>
      <Outlet />
    </ErrorBoundary>
  );
}

const router = createBrowserRouter([
  { path: "/", element: <Navigate to="/en" replace /> },
  { path: "/admin", element: <Navigate to="/en/admin" replace /> },
  { path: "/admin/*", element: <Navigate to="/en/admin" replace /> },
  { path: "/live/*", element: <Navigate to="/en" replace /> },
  {
    path: "/:lang",
    element: <LangWrapper />,
    children: [
      { index: true, element: <Home /> },
      { path: "about", element: <About /> },
      { path: "join", element: <JoinUs /> },
      { path: "women", element: <WomenPage /> },
      { path: "tourism", element: <TourismPage /> },
      { path: "books", element: <BooksPage /> },
      { path: "podcasts", element: <PodcastsPage /> },
      { path: "visa-flights", element: <VisaFlightPage /> },
      { path: "article/:slug", element: <ArticlePage /> },
      { path: "category/:slug", element: <CategoryPage /> },
      { path: "search", element: <SearchWrapper /> },
      { path: "live", element: <LivePortal /> },
      { path: "live/:slug", element: <LiveEventPage /> }
    ]
  },
  {
    path: "/:lang/admin",
    element: <AdminLangWrapper />,
    children: [
      { index: true, element: <AdminDashboard /> },
      { path: "articles", element: <AdminArticles /> },
      { path: "articles/new", element: <AdminArticleNew /> },
      { path: "women", element: <AdminLayout><AdminWomen /></AdminLayout> },
      { path: "tourism", element: <AdminLayout><AdminTourism /></AdminLayout> },
      { path: "visa-flights", element: <AdminLayout><AdminVisaFlight /></AdminLayout> },
      { path: "podcasts", element: <AdminLayout><AdminPodcasts /></AdminLayout> },
      { path: "live-events", element: <AdminLiveEvents /> },
      { path: "books", element: <AdminBooks /> },
      { path: "live-publish", element: <AdminDashboard /> },
      { path: "market", element: <AdminLayout><AdminMarketData /></AdminLayout> },
      { path: "users", element: <AdminUsers /> },
      { path: "media", element: <AdminMedia /> },
      { path: "settings", element: <AdminSettings /> }
    ]
  },
  { path: "*", element: <NotFound /> }
]);

export default function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <ThemeApplier />
      <RouterProvider router={router} />
    </QueryClientProvider>
  );
}

