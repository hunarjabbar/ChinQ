import { useParams, useNavigate } from 'react-router-dom';
import { useEffect, useState } from 'react';
import { LiveTimeline } from '../components/LiveTimeline';
import { Video, Radio } from 'lucide-react';

export function LiveEventPage() {
  const { lang, slug } = useParams();
  const navigate = useNavigate();
  const [event, setEvent] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchEvent = async () => {
      try {
        const timestamp = new Date().getTime();
        const res = await fetch(`/api/events/${slug}?t=${timestamp}`, { cache: 'no-store' });
        if (!res.ok) {
          if (res.status === 404) {
            navigate(`/${lang}/not-found`);
            return;
          }
          throw new Error('Failed to fetch event');
        }
        const data = await res.json();
        setEvent(data);
      } catch (err) {
        console.error(err);
      } finally {
        setLoading(false);
      }
    };
    fetchEvent();
  }, [slug, lang, navigate]);

  if (loading) {
    return <div className="min-h-[50vh] flex items-center justify-center">Loading...</div>;
  }

  if (!event) {
    return null; // Handled by navigate to 404
  }

  const getTitle = () => {
    if (lang === 'ar') return event.titleAr;
    if (lang === 'ckb') return event.titleCkb || event.titleEn;
    if (lang === 'zh') return event.titleZh;
    return event.titleEn;
  };

  const getSummary = () => {
    if (lang === 'ar') return event.summaryAr;
    if (lang === 'ckb') return event.summaryCkb || event.summaryEn;
    if (lang === 'zh') return event.summaryZh;
    return event.summaryEn;
  }

  return (
    <main className="bg-white min-h-screen w-full">
      {/* Live Event Hero */}
      <div className="bg-brand-800 text-white py-20 px-4 sm:px-6 lg:px-8 border-b-8 border-brand-800 w-full">
        <div className="max-w-6xl mx-auto">
          <span className="inline-flex items-center gap-2 bg-brand-800 text-white text-xs font-black uppercase tracking-widest px-3 py-1.5 rounded-sm mb-4">
            {event.isActive && <span className="w-1.5 h-1.5 rounded-full bg-white animate-pulse"></span>}
            {lang === 'ar' ? 'تغطية مباشرة' : lang === 'ckb' ? 'ڕووماڵی ڕاستەوخۆ' : lang === 'zh' ? '现场直播' : 'Live Coverage'}
          </span>
          <h1 className="text-4xl sm:text-5xl font-serif font-black leading-tight mb-4">
            {getTitle()}
          </h1>
          <p className="text-lg text-gray-400 max-w-3xl leading-relaxed">
            {getSummary()}
          </p>
        </div>
      </div>

      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-20 flex flex-col lg:flex-row gap-8">
        <div className="flex-1 space-y-8">
          
          {/* Main Video/Stream Area */}
          <div className="relative aspect-video bg-black rounded-xl overflow-hidden border border-gray-200 shadow-sm hover:shadow-md group">
            {event.videoUrl ? (
              <iframe 
                src={event.videoUrl} 
                title={getTitle()}
                className="w-full h-full border-0 absolute inset-0 z-10"
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                allowFullScreen
              ></iframe>
            ) : (
              <div className="absolute inset-0 flex items-center justify-center bg-gray-900">
                <div className="flex flex-col items-center gap-4 text-gray-500">
                  <div className="w-16 h-16 rounded-full bg-gray-800 flex items-center justify-center">
                    <Radio size={32} className="text-gray-400 opacity-50" />
                  </div>
                  <span className="text-xs font-bold uppercase tracking-widest">No Live Video Signal Detected</span>
                </div>
              </div>
            )}
            
            {event.isActive && event.videoUrl && (
              <div className="absolute top-4 left-4 z-20 pointer-events-none">
                <div className="bg-brand-800 text-white text-[10px] font-black uppercase tracking-widest px-3 py-1 rounded flex items-center gap-2 shadow-sm hover:shadow-md">
                  <span className="w-2 h-2 rounded-full bg-white animate-pulse"></span>
                  LIVE
                </div>
              </div>
            )}
          </div>

          <LiveTimeline slug={slug as string} lang={lang as 'en' | 'ar' | 'zh' | 'ckb'} />
        </div>
        
        {/* Optional Sidebar for Context */}
        <div className="hidden lg:block w-72 lg:w-80 border-s border-gray-200 ps-8">
          <div className="bg-gray-50 p-6 rounded-xl border border-gray-200 mb-6">
            <h3 className="font-bold uppercase tracking-wider text-sm mb-4 border-b border-gray-200 pb-2">
              Broadcast Info
            </h3>
            <div className="space-y-4">
              <div>
                <span className="block text-[10px] text-gray-500 font-bold uppercase tracking-widest mb-1">Region</span>
                <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded bg-white border border-gray-200 text-xs font-bold text-gray-700">
                  {event.region}
                </span>
              </div>
              <div>
                <span className="block text-[10px] text-gray-500 font-bold uppercase tracking-widest mb-1">Category</span>
                <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded bg-white border border-gray-200 text-xs font-bold text-gray-700">
                  {event.category}
                </span>
              </div>
              <div>
                <span className="block text-[10px] text-gray-500 font-bold uppercase tracking-widest mb-1">Status</span>
                <span className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded border text-xs font-bold ${
                  event.isActive ? 'bg-brand-50 border-brand-200 text-brand-700' : 'bg-gray-100 border-gray-200 text-gray-700'
                }`}>
                  {event.isActive && <span className="w-1.5 h-1.5 rounded-full bg-brand-500 animate-pulse"></span>}
                  {event.isActive ? 'LIVE' : 'ARCHIVED'}
                </span>
              </div>
            </div>
          </div>

          <h3 className="font-bold uppercase tracking-wider text-sm mb-4 border-b border-gray-200 pb-2">
            {lang === 'ar' ? 'سياق' : lang === 'ckb' ? 'پاشخان' : lang === 'zh' ? '背景' : 'Context'}
          </h3>
          <p className="text-sm text-gray-600 leading-relaxed bg-neutral-50 p-4 rounded-lg border border-neutral-100">
            {lang === 'ar' 
              ? 'هذه قصة قيد التطوير. تقوم فرق التحرير لدينا في بكين والسليمانية بتحديث هذه الصفحة في الوقت الفعلي. تعكس الطوابع الزمنية التوقيت المحلي العراقي (UTC+3).'
              : lang === 'ckb'
              ? 'ئەمە ڕووداوێکی بەردەوامە. تیمەکانی نووسینمان لە بێجینگ و سلێمانی ئەم لاپەڕەیە لە کاتی ڕاستەقینەدا نوێ دەکەنەوە. کاتەکان کاتی خۆجێیی عێراق نیشان دەدەن (UTC+3).'
              : lang === 'zh'
              ? '这是一个正在发展的故事。我们在北京和苏莱曼尼亚的编辑团队正在实时更新此页面。时间戳反映了伊拉克当地时间（UTC+3）。'
              : 'This is a developing story. Our editorial teams in Beijing and Sulaymaniyah are updating this page in real-time. Timestamps reflect local Iraqi Time (UTC+3).'}
          </p>
        </div>
      </div>
    </main>
  );
}
