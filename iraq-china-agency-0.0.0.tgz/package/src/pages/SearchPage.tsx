import React, { useMemo } from 'react';
import { useSearchParams } from 'react-router-dom';
import { Locale } from '../types';

export default function SearchPage({ lang }: { lang: Locale }) {
  const [searchParams] = useSearchParams();
  const query = searchParams.get('q') || '';

  const projects = [
    {
      id: 1,
      name: lang === 'zh' ? '法奥大港' : 'Al Faw Grand Port',
      status: lang === 'zh' ? '建设中' : 'Under Construction',
      value: '$2.6B',
      desc: lang === 'zh' ? '连接波斯湾的超级港口项目。' : 'Mega-port project connecting the Persian Gulf.',
      type: 'project'
    },
    {
      id: 2,
      name: lang === 'zh' ? '发展路项目' : 'Development Road',
      status: lang === 'zh' ? '规划中' : 'Planning',
      value: '$17B',
      desc: lang === 'zh' ? '通过土耳其连接伊拉克和欧洲的铁路网络。' : 'Rail network linking Iraq to Europe via Turkey.',
      type: 'project'
    },
    {
      id: 3,
      name: lang === 'zh' ? '纳西里耶国际机场' : 'Nasiriyah International Airport',
      status: lang === 'zh' ? '建设中' : 'Under Construction',
      value: '$367M',
      desc: lang === 'zh' ? '中国建筑集团承建的现代化机场。' : 'Modern airport constructed by CSCEC.',
      type: 'project'
    }
  ];

  const enterprises = [
    {
      id: 1,
      name: 'PowerChina',
      sector: 'Energy & Infrastructure',
      verified: true,
      type: 'enterprise'
    },
    {
      id: 2,
      name: 'Huawei Technologies Iraq',
      sector: 'Telecommunications',
      verified: true,
      type: 'enterprise'
    },
    {
      id: 3,
      name: 'ZPEC (Zhongman Petroleum)',
      sector: 'Oil & Gas Services',
      verified: true,
      type: 'enterprise'
    },
    {
      id: 4,
      name: 'CSCEC Middle East',
      sector: 'Construction',
      verified: true,
      type: 'enterprise'
    }
  ];

  const allItems = [...projects, ...enterprises];

  const filteredItems = useMemo(() => {
    if (!query) return allItems;
    const lowerQuery = query.toLowerCase();
    return allItems.filter(item => {
      const matchName = item.name.toLowerCase().includes(lowerQuery);
      const matchSector = ('sector' in item) && item.sector.toLowerCase().includes(lowerQuery);
      const matchDesc = ('desc' in item) && item.desc.toLowerCase().includes(lowerQuery);
      return matchName || matchSector || matchDesc;
    });
  }, [query, allItems]);

  const pageTitle = lang === 'zh' ? '全局搜索' : 'Global Search';
  const resultsLabel = lang === 'zh' ? '结果' : 'Results for';

  return (
    <div className="max-w-[1024px] mx-auto px-4 sm:px-6 py-20 min-h-screen">
      <h1 className="text-3xl font-serif font-black text-ink-900 mb-2">{pageTitle}</h1>
      <p className="text-gray-600 mb-12">{resultsLabel}: <span className="font-bold text-brand-800">"{query}"</span></p>

      {filteredItems.length === 0 ? (
        <p className="text-gray-500">{lang === 'zh' ? '没有找到相关结果。' : 'No results found.'}</p>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {filteredItems.map(item => (
            <div key={`${item.type}-${item.id}`} className="border border-[#E5E5E5] p-6 bg-white hover:border-brand-800 transition-colors">
              <div className="text-xs font-bold uppercase tracking-widest text-brand-800 mb-2">
                {item.type === 'project' ? (lang === 'zh' ? '基建项目' : 'Infrastructure Project') : (lang === 'zh' ? '认证企业' : 'Verified Enterprise')}
              </div>
              <h3 className="text-xl font-bold text-ink-900 mb-2">{item.name}</h3>
              {item.type === 'project' && (
                <>
                  <div className="text-sm font-semibold text-gray-700 mb-2">{('value' in item) ? item.value : ''} • {('status' in item) ? item.status : ''}</div>
                  <p className="text-sm text-gray-500">{('desc' in item) ? item.desc : ''}</p>
                </>
              )}
              {item.type === 'enterprise' && (
                <div className="text-sm font-semibold text-gray-700 mb-2">Sector: {('sector' in item) ? item.sector : ''}</div>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
