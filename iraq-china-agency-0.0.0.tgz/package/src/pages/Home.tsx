import DOMPurify from 'dompurify';
import { SubscriptionCard } from '../components/SubscriptionCard';
import { motion } from 'motion/react';
import { useQuery } from '@tanstack/react-query';
import { useParams, Link } from 'react-router-dom';
import { useState, useCallback, useMemo, useEffect, useRef } from 'react';
import { Article, Locale, Study, MarketData } from '../types';
import { useI18n } from '../hooks/useI18n';
import { useAuthStore } from '../store/useAuthStore';
import { BookOpen, Lock, ChevronRight, ChevronLeft, Sparkles, AlertCircle, Activity, Flame } from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';
import { ar, zhCN, enUS } from 'date-fns/locale';
import { cn } from '../lib/utils';
import { InvestIraq } from '../components/InvestIraq';
import { ContactUs } from '../components/ContactUs';
import { MarketIndicesSection } from '../components/MarketIndicesSection';
import { TrendingBooksSection } from '../components/TrendingBooksSection';
import { RecommendedBooksSection } from '../components/RecommendedBooksSection';
import { TourismSection } from '../components/TourismSection';
import { WomenSection } from '../components/WomenSection';
import { VisaFlightSection } from '../components/VisaFlightSection';
import { ArticleModal } from '../components/ArticleModal';

export function Home() {
  const { lang } = useParams<{ lang: Locale }>();
  const { t } = useI18n(lang!);
  const [selectedArticle, setSelectedArticle] = useState<Article | null>(null);
  const [selectedStudy, setSelectedStudy] = useState<Study | null>(null);
  const [marketData, setMarketData] = useState<MarketData[]>([]);
  const trendingScrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    fetch('/api/market')
      .then(res => res.json())
      .then(items => {
        if (Array.isArray(items) && items.length > 0) {
          setMarketData(items);
        }
      })
      .catch(() => {});

    const eventSource = new EventSource('/api/market/stream');
    eventSource.onmessage = (event) => {
      try {
        const parsed = JSON.parse(event.data);
        if (Array.isArray(parsed)) {
          setMarketData(parsed);
        }
      } catch (e) {
        console.error("Failed to parse market stream", e);
      }
    };
    return () => {
      eventSource.close();
    };
  }, []);
  
  const { user } = useAuthStore();
  const isSubscribed = user?.subscriptionStatus === 'ACTIVE';

  const { data: articles = [], isLoading } = useQuery<Article[]>({
    queryKey: ['articles'],
    queryFn: async () => {
      const res = await fetch('/api/articles');
      if (!res.ok) throw new Error('Network response was not ok');
      return res.json();
    }
  });

  const { data: studies = [] } = useQuery<Study[]>({
    queryKey: ['studies'],
    queryFn: async () => {
      const res = await fetch('/api/studies');
      if (!res.ok) throw new Error('Network response was not ok');
      return res.json();
    }
  });

  const getStudyTitle = useCallback((study: Study) => {
    if (lang === 'ar') return study.titleAr;
    if (lang === 'zh') return study.titleZh;
    if (lang === 'ckb') return study.titleCkb || study.titleEn;
    return study.titleEn;
  }, [lang]);

  const getStudyExcerpt = useCallback((study: Study) => {
    if (lang === 'ar') return study.excerptAr;
    if (lang === 'zh') return study.excerptZh;
    if (lang === 'ckb') return study.excerptCkb || study.excerptEn;
    return study.excerptEn;
  }, [lang]);

  const getStudyContent = useCallback((study: Study) => {
    if (lang === 'ar') return study.contentAr;
    if (lang === 'zh') return study.contentZh;
    if (lang === 'ckb') return study.contentCkb || study.contentEn;
    return study.contentEn;
  }, [lang]);

  const getTranslation = useCallback((article: Article) => {
    return article.translations.find(tr => tr.lang === lang) || 
           article.translations.find(tr => tr.lang === 'en') || 
           article.translations[0];
  }, [lang]);

  const getCategoryName = useCallback((category: any) => {
    if (!category) return '';
    if (lang === 'ar') return category.nameAr || category.name;
    if (lang === 'zh') return category.nameZh || category.name;
    if (lang === 'ckb') {
      const name = category.nameEn || category.name;
      if (name === 'Energy') return 'وزە';
      if (name === 'Economy') return 'ئابووری';
      if (name === 'Culture') return 'کالچەر';
      if (name === 'AI') return 'زیرەکی دەستکرد';
      if (name === 'Food & Beverage') return 'خۆراک و خواردنەوە';
      if (name === 'Expo') return 'پێشانگا';
      if (name === 'Business Statistics') return 'ئاماری بازرگانی';
      return name;
    }
    return category.nameEn || category.name;
  }, [lang]);

  const dateLocale = useMemo(() => lang === 'ar' ? ar : lang === 'zh' ? zhCN : enUS, [lang]);

  if (isLoading) {
    return (
      <div className="animate-pulse space-y-8 w-full max-w-[1024px] mx-auto p-6">
        <div className="h-96 bg-neutral-200 rounded-lg w-full"></div>
      </div>
    );
  }

  if (articles.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center py-24 max-w-[1024px] mx-auto w-full">
        <p className="text-gray-500 font-serif italic text-lg">No stories available at this time.</p>
      </div>
    );
  }

  const handleTrendingScroll = (direction: 'left' | 'right') => {
    if (trendingScrollRef.current) {
      const isRtl = lang === 'ar' || lang === 'ckb';
      const scrollAmount = trendingScrollRef.current.clientWidth * 0.75;
      const delta = direction === 'left' ? -scrollAmount : scrollAmount;
      trendingScrollRef.current.scrollBy({
        left: isRtl ? -delta : delta,
        behavior: 'smooth'
      });
    }
  };

  const leadStory = articles[0];
  const popularStories = articles.slice(0, 5); // Popular stories list

  return (
    <div className="flex flex-col w-full bg-paper-50">
      
      {/* IRAQ-CHINA DAILY DAILY VERTICAL TICKER */}
      <div className="w-full max-w-[1024px] mx-auto bg-brand-800 text-white border-b-4 border-brand-800 flex overflow-hidden h-12 relative items-center px-4 shadow-sm">
        <div className="flex-shrink-0 font-serif font-black text-white pe-4 border-e border-white/20 uppercase tracking-widest text-sm z-10 bg-brand-800 h-full flex items-center shadow-sm hover:shadow-md">
          <Activity size={16} className="me-2 text-brand-800 animate-pulse" />
          {lang === 'ar' ? 'وكالة العراق والصين' : lang === 'zh' ? '伊拉克-中国通讯社' : lang === 'ckb' ? 'ئاژانسی عێراق - چین' : 'IRAQ - CHINA AGENCY'}
        </div>
        <div className="flex-grow h-full relative overflow-hidden ms-4">
          <div className="animate-marquee-vertical flex flex-col absolute top-0 left-0 w-full">
            {[...articles.slice(0, 8), ...articles.slice(0, 8)].map((article, i) => {
              const tr = getTranslation(article);
              return (
                 <div key={`${article.id}-${i}`} className="h-12 flex items-center shrink-0 cursor-pointer hover:text-brand-800 transition-colors" onClick={() => setSelectedArticle(article)}>
                   <span className="text-[10px] text-gray-400 font-mono me-3 shrink-0">{new Date(article.createdAt).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}</span>
                   <span className="text-sm font-bold font-serif line-clamp-1">{tr?.title}</span>
                 </div>
              )
            })}
          </div>
        </div>
      </div>

      <main className="flex-grow grid grid-cols-1 lg:grid-cols-12 divide-y lg:divide-y-0 lg:divide-x rtl:divide-x-reverse divide-ink-900/10 w-full max-w-[1024px] mx-auto bg-paper-50 relative">
      
      {/* Section 1: Full-Scale Upper Trending Carousel with Covers & Navigation Arrows */}
      <section className="lg:col-span-12 p-4 sm:p-6 bg-gradient-to-r from-brand-800 via-brand-800 to-brand-800 text-white border-b-2 border-brand-800 relative overflow-hidden">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <span className="flex items-center justify-center w-6 h-6 bg-brand-800 text-white rounded-full">
              <Flame size={14} className="animate-pulse" />
            </span>
            <h3 className="text-xs sm:text-sm font-black uppercase tracking-widest text-white">
              {t('trending')}
            </h3>
            <span className="hidden sm:inline-block text-[10px] text-gray-400 font-mono ms-2">
              • {articles.length} {lang === 'ar' ? 'موضوعات شائعة' : lang === 'zh' ? '热门主题' : lang === 'ckb' ? 'بابەتە گەرمەکان' : 'Featured Topics'}
            </span>
          </div>

          {/* Navigation Arrows */}
          <div className="flex items-center gap-1.5">
            <button
              onClick={() => handleTrendingScroll('left')}
              className="p-1.5 sm:p-2 rounded-full bg-white/10 hover:bg-brand-800 text-white transition-colors border border-white/10 shadow-sm cursor-pointer active:scale-95"
              aria-label="Scroll Left"
            >
              <ChevronLeft size={18} className="rtl:rotate-180" />
            </button>
            <button
              onClick={() => handleTrendingScroll('right')}
              className="p-1.5 sm:p-2 rounded-full bg-white/10 hover:bg-brand-800 text-white transition-colors border border-white/10 shadow-sm cursor-pointer active:scale-95"
              aria-label="Scroll Right"
            >
              <ChevronRight size={18} className="rtl:rotate-180" />
            </button>
          </div>
        </div>

        {/* Scrollable Topic Covers Track */}
        <div 
          ref={trendingScrollRef}
          className="flex gap-4 overflow-x-auto no-scrollbar scroll-smooth pb-2 pt-1 -mx-1 px-1"
        >
          {articles.map((article) => {
            const tr = getTranslation(article);
            return (
              <div 
                key={`trending-cover-${article.id}`} 
                onClick={() => setSelectedArticle(article)}
                className="group shrink-0 w-[240px] sm:w-[280px] bg-white/5 hover:bg-white/10 border border-white/10 rounded-lg overflow-hidden transition-all duration-300 cursor-pointer shadow-sm hover:shadow-md hover:border-brand-800/80 flex flex-col justify-between"
              >
                {/* Topic Cover Image */}
                <div className="relative w-full h-[150px] sm:h-[160px] bg-brand-800/80 overflow-hidden">
                  {article.imageUrl ? (
                    <img 
                      src={article.imageUrl} 
                      alt={tr?.title || 'Topic Cover'}
                      className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                      loading="lazy"
                    />
                  ) : (
                    <div className="w-full h-full flex items-center justify-center bg-gradient-to-br from-brand-800/80 to-brand-800 text-gray-500">
                      <span className="font-serif italic text-xs">
                        {lang === 'ar' ? 'موضوع الوكالة' : lang === 'zh' ? '伊拉克-中国通讯社专题' : lang === 'ckb' ? 'بابەتی ئاژانس' : 'Iraq - China Agency Topic'}
                      </span>
                    </div>
                  )}
                  {/* Category Badge */}
                  <div className="absolute top-2.5 start-2.5 bg-brand-800 text-white text-[9px] font-black uppercase px-2 py-0.5 rounded shadow-md tracking-wider">
                    {getCategoryName(article.category)}
                  </div>
                  {/* Subtle Overlay */}
                  <div className="absolute inset-0 bg-gradient-to-t from-[#1A1A1A]/80 via-transparent to-transparent opacity-60 group-hover:opacity-40 transition-opacity" />
                </div>

                {/* Topic Info */}
                <div className="p-3.5 sm:p-4 flex flex-col justify-between flex-grow space-y-2">
                  <h4 className="font-serif text-sm sm:text-base font-bold leading-snug text-white group-hover:text-brand-400 transition-colors line-clamp-2">
                    {tr?.title}
                  </h4>
                  <p className="text-[11px] text-gray-300 line-clamp-2 leading-relaxed opacity-85">
                    {tr?.excerpt}
                  </p>
                  <div className="flex items-center justify-between text-[9px] text-gray-400 font-mono pt-2 border-t border-white/10">
                    <span>{formatDistanceToNow(new Date(article.createdAt), { addSuffix: true, locale: dateLocale })}</span>
                    <span className="text-brand-400 font-bold group-hover:translate-x-1 transition-transform rtl:group-hover:-translate-x-1">→</span>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </section>

      {/* Column 2: Lead Story */}
      <section className="lg:col-span-7 p-6 overflow-hidden">
        {leadStory && (
          <div 
            onClick={() => setSelectedArticle(leadStory)}
            className="cursor-pointer group"
          >
            <div className="relative mb-4 overflow-hidden rounded-sm border border-brand-800/5">
              <div className="w-full h-[280px] bg-brand-800/10 overflow-hidden">
                {leadStory.imageUrl ? (
                  <img 
                    src={leadStory.imageUrl} 
                    alt={getTranslation(leadStory)?.title || 'Lead story image'}
                    className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-102"
                    fetchPriority="high"
                  />
                ) : (
                  <div className="w-full h-full flex items-center justify-center bg-brand-800/5">
                    <span className="text-gray-400 font-serif italic">Image not available</span>
                  </div>
                )}
              </div>
              <div className="absolute bottom-0 start-0 bg-brand-800 text-white text-[9px] font-bold uppercase px-2 py-1">
                {lang === 'ar' ? 'تقرير خاص' : lang === 'ckb' ? 'ڕاپۆرتی تایبەت' : lang === 'zh' ? '特别报道' : 'Special Report'}
              </div>
            </div>
            
            <h2 className="font-serif text-3xl md:text-4xl font-black leading-[1.1] mb-4 text-center px-4 tracking-tight text-ink-900 group-hover:text-brand-800 group-hover:underline transition-colors">
              {getTranslation(leadStory)?.title}
            </h2>
            
            <div className="flex justify-center space-x-4 rtl:space-x-reverse text-[10px] font-bold uppercase mb-4 opacity-60 text-ink-900">
              <span>By {(leadStory as any).author?.name || 'Staff Reporter'}</span>
              <span>•</span>
              <span>
                {formatDistanceToNow(new Date(leadStory.createdAt), { addSuffix: true, locale: dateLocale })}
              </span>
            </div>

            <p className="text-sm leading-relaxed text-gray-800 first-letter:text-5xl first-letter:font-bold first-letter:font-serif first-letter:float-start first-letter:pe-2">
              {getTranslation(leadStory)?.excerpt || getTranslation(leadStory)?.content?.substring(0, 200)}...
            </p>
          </div>
        )}
      </section>

      {/* Column 3: Most Popular & Widget */}
      <section className="lg:col-span-5 flex flex-col">
        <div className="p-6 bg-paper-50 border-b border-brand-800/10 flex-grow shadow-xs">
          <h3 className="text-[10px] uppercase font-black tracking-widest mb-4 flex items-center text-ink-900 border-b border-brand-800/20 pb-2">
            <span className="w-2 h-2 bg-brand-800 rounded-full me-2 animate-pulse"></span>
            {t('beltRoad')}
          </h3>
          <div className="space-y-4">
            <div className="border-s-2 border-brand-800 ps-3 bg-white/60 p-2.5 rounded-r shadow-2xs">
              <div className="text-[9px] font-bold text-gray-500 uppercase tracking-wide">Maysan Province</div>
              <div className="text-xs font-bold text-ink-900">Solar Farm Stage 2</div>
              <div className="w-full bg-brand-800/10 h-1.5 mt-1.5 rounded-full overflow-hidden">
                <div className="bg-brand-800 h-1.5 w-[85%] transition-all duration-500 rounded-full"></div>
              </div>
            </div>
            <div className="border-s-2 border-gray-300 ps-3 bg-white/40 p-2.5 rounded-r">
              <div className="text-[9px] font-bold text-gray-500 uppercase tracking-wide">Anbar Refinery</div>
              <div className="text-xs font-bold text-ink-900">Technical Feasibility</div>
              <div className="w-full bg-brand-800/10 h-1.5 mt-1.5 rounded-full overflow-hidden">
                <div className="bg-brand-800 h-1.5 w-[32%] transition-all duration-500 rounded-full"></div>
              </div>
            </div>
          </div>

          <div className="mt-8">
            <h3 className="text-[10px] uppercase font-black border-b border-brand-800 pb-1.5 mb-4 text-ink-900 tracking-wider">
              {t('popular')}
            </h3>
            <ol className="space-y-3.5 list-decimal list-inside text-sm text-ink-900">
              {popularStories.map((article) => (
                <li 
                  key={`pop-${article.id}`} 
                  onClick={() => setSelectedArticle(article)}
                  className="font-serif font-bold leading-snug cursor-pointer hover:text-brand-800 transition-colors"
                >
                  <span className="inline-block align-top max-w-[90%] ms-1 hover:underline">
                    {getTranslation(article)?.title}
                  </span>
                </li>
              ))}
            </ol>
          </div>
        </div>
        
        {/* LIVE COVERAGE HIGHLIGHT */}
        <div className="bg-gradient-to-br from-brand-50 to-white border border-brand-200/80 p-6 mb-6 rounded-md shadow-sm">
          <div className="flex items-center gap-2 mb-3 text-brand-800 font-bold uppercase text-xs tracking-wider">
            <span className="relative flex h-2.5 w-2.5">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-brand-800 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-brand-800"></span>
            </span>
            {lang === 'ar' ? 'تغطية مباشرة' : lang === 'ckb' ? 'رووماڵی ڕاستەوخۆ' : lang === 'zh' ? '现场直播' : 'Live Coverage'}
          </div>
          <h3 className="font-serif font-black text-xl mb-2.5 leading-tight text-ink-900">
            <Link to={`/${lang}/live/iraq-china-summit-2026`} className="hover:text-brand-800 transition-colors hover:underline">
              {lang === 'ar' ? 'القمة الاقتصادية العراقية الصينية 2026' : lang === 'ckb' ? 'لووتکەی ئابووری عێراق-چین ٢٠٢٦' : lang === 'zh' ? '2026年伊拉克-中国经济峰会' : 'Iraq-China Economic Summit 2026'}
            </Link>
          </h3>
          <p className="text-xs text-gray-600 mb-4 leading-relaxed">
            {lang === 'ar' 
              ? 'تحديثات في الوقت الفعلي من قمة الشراكة الاستراتيجية في بكين.' 
              : lang === 'ckb' 
              ? 'تایبەتمەندی و نوێکاری ڕاستەوخۆ لە لوتکەی پەکین بۆ هاوبەشی ستراتیژی.' 
              : lang === 'zh' 
              ? '北京战略合作伙伴关系峰会实时更新。' 
              : 'Real-time updates from the strategic partnership summit in Beijing.'}
          </p>
          <Link 
            to={`/${lang}/live/iraq-china-summit-2026`} 
            className="inline-flex items-center gap-1.5 text-xs font-bold uppercase tracking-wider text-brand-800 hover:text-black transition-colors group"
          >
            <span>{lang === 'ar' ? 'متابعة التحديثات' : lang === 'ckb' ? 'سەیرکردنی نوێکارییەکان' : lang === 'zh' ? '关注更新' : 'Follow Updates'}</span>
            <span className="group-hover:translate-x-1 transition-transform rtl:group-hover:-translate-x-1">→</span>
          </Link>
        </div>

        {/* ENTERPRISE CALL TO ACTION */}
        <SubscriptionCard />
      </section>

      {/* CHINA & HONG KONG STOCK CHARTS & INDICES TERMINAL SECTION */}
      <div className="w-full max-w-[1024px] mx-auto my-8 px-4 sm:px-6">
        <MarketIndicesSection data={marketData} lang={lang!} />
      </div>

      {/* OPINION & ANALYSIS BOARD */}
      {articles.filter(a => a.category?.slug === 'opinion').length > 0 && (
        <section className="w-full max-w-[1024px] mx-auto bg-white border-t-4 border-b-2 border-brand-800 p-6 md:p-8 mt-12 animate-fadeIn shadow-xs">
          <div className="flex justify-between items-baseline border-b border-brand-800/15 pb-3 mb-6">
            <h2 className="font-serif text-2xl md:text-3xl font-black tracking-tight text-ink-900 uppercase flex items-center gap-2">
              <span className="w-3.5 h-3.5 bg-brand-800 rounded-2xs"></span>
              {lang === 'ar' ? 'آراء وتحليلات' : lang === 'zh' ? '观点与深度分析' : lang === 'ckb' ? 'ڕاو بۆچوون و شیکردنەوە' : 'Opinion & Analysis'}
            </h2>
            <Link 
              to={`/${lang}/category/opinion`} 
              className="text-xs font-black uppercase tracking-widest text-brand-800 hover:underline flex items-center gap-1 group"
            >
              <span>{lang === 'ar' ? 'عرض جميع الآراء' : lang === 'zh' ? '查看所有观点' : lang === 'ckb' ? 'بینینی هەموو ڕاکان' : 'View All Opinions'}</span>
              <span className="group-hover:translate-x-1 transition-transform rtl:group-hover:-translate-x-1">→</span>
            </Link>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 divide-y md:divide-y-0 md:divide-x rtl:divide-x-reverse divide-ink-900/10">
            {articles.filter(a => a.category?.slug === 'opinion').slice(0, 4).map((article, idx) => {
              const tr = getTranslation(article);
              const authorName = (article as any).author?.name || 'Staff Writer';
              const initial = authorName.replace(/^(Dr\.|Amb\.|Prof\.)\s+/i, '').charAt(0);
              const avatarBg = ['bg-brand-50', 'bg-amber-50', 'bg-emerald-50', 'bg-stone-100'][idx % 4];
              const textAccent = ['text-brand-800', 'text-amber-800', 'text-emerald-800', 'text-ink-900'][idx % 4];
              
              return (
                <div 
                  key={article.id}
                  onClick={() => setSelectedArticle(article)}
                  className="cursor-pointer group flex flex-col justify-between pt-4 md:pt-0 md:px-4 first:pl-0 last:pr-0 border-brand-800/10"
                >
                  <div className="space-y-3">
                    <div className="flex items-center gap-3">
                      <div className={cn("w-10 h-10 rounded-full flex items-center justify-center font-serif text-base font-black border border-brand-800/10 shrink-0 shadow-xs", avatarBg, textAccent)}>
                        {initial}
                      </div>
                      <div className="leading-tight">
                        <h4 className="text-xs font-black uppercase tracking-wider text-ink-900 group-hover:text-brand-800 transition-colors">
                          {authorName}
                        </h4>
                        <span className="text-[9px] uppercase font-bold text-gray-500 block tracking-wider">
                          {idx < 2 ? (lang === 'zh' ? '特约撰稿人' : 'Contributor') : (lang === 'zh' ? '智库学者' : 'Guest Analyst')}
                        </span>
                      </div>
                    </div>

                    <h3 className="font-serif font-bold text-base leading-snug text-ink-900 group-hover:text-brand-800 transition-colors line-clamp-3 italic pt-2 border-t border-brand-800/5">
                      “{tr?.title}”
                    </h3>
                    
                    <p className="text-[11px] text-gray-600 line-clamp-3 leading-relaxed">
                      {tr?.excerpt}
                    </p>
                  </div>
                  
                  <span className="text-[9px] font-mono uppercase tracking-wider text-gray-400 mt-4 block">
                    {new Date(article.createdAt).toLocaleDateString(dateLocale.code)}
                  </span>
                </div>
              );
            })}
          </div>
        </section>
      )}

      {/* IRAQ-CHINA DAILY SPECIAL STUDIES & DEEP RESEARCH (SECTION 5) */}
      {studies.length > 0 && (
        <section className="w-full max-w-[1024px] mx-auto bg-white border-t-4 border-double border-brand-800 p-6 md:p-8 space-y-6 shadow-xs mt-8">
          <div className="flex justify-between items-center border-b border-brand-800/10 pb-4">
            <div className="flex items-center gap-2.5">
              <BookOpen className="text-brand-800" size={22} />
              <h2 className="font-serif text-2xl md:text-3xl font-black text-ink-900 tracking-tight">
                {t('studies')}
              </h2>
            </div>
            <span className="text-[10px] font-mono uppercase tracking-widest bg-neutral-100 text-neutral-600 px-3 py-1 border border-neutral-200 font-bold rounded-sm shadow-2xs">
              {lang === 'ar' ? 'استخبارات وكالة العراق والصين' : lang === 'zh' ? '伊拉克-中国通讯社智库情报' : lang === 'ckb' ? 'هەواڵگری ئاژانسی عێراق - چین' : 'Iraq - China Agency Intelligence'}
            </span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {studies.map((study) => {
              const isLocked = study.isPrivate && !isSubscribed;
              return (
                <div 
                  key={study.id}
                  onClick={() => setSelectedStudy(study)}
                  className="group cursor-pointer flex flex-col justify-between bg-neutral-50/50 hover:bg-white border border-neutral-200 hover:border-brand-800/60 transition-all duration-300 rounded-md overflow-hidden shadow-sm hover:shadow-md"
                >
                  <div className="space-y-4">
                    {study.imageUrl && (
                      <div className="relative w-full aspect-video overflow-hidden border-b border-neutral-200">
                        <img 
                          src={study.imageUrl} 
                          alt={getStudyTitle(study)} 
                          className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                          referrerPolicy="no-referrer"
                        />
                        {isLocked && (
                          <div className="absolute inset-0 bg-black/40 backdrop-blur-[1px] flex items-center justify-center">
                            <div className="bg-black/80 text-amber-400 text-xs px-3.5 py-1.5 rounded-full flex items-center gap-1.5 font-bold uppercase tracking-wider shadow-sm border border-amber-500/30">
                              <Lock size={12} className="animate-pulse" />
                              <span>{lang === 'ar' ? 'مغلق' : lang === 'ckb' ? 'داخراو' : lang === 'zh' ? '加锁专享' : 'Premium Lock'}</span>
                            </div>
                          </div>
                        )}
                        <div className="absolute top-2.5 start-2.5 flex gap-1.5">
                          {study.isPrivate ? (
                            <span className="bg-amber-500 text-white text-[9px] font-black uppercase tracking-widest px-2 py-0.5 rounded shadow-sm">
                              PREMIUM
                            </span>
                          ) : (
                            <span className="bg-emerald-600 text-white text-[9px] font-black uppercase tracking-widest px-2 py-0.5 rounded shadow-sm">
                              OPEN ACCESS
                            </span>
                          )}
                        </div>
                      </div>
                    )}

                    <div className="p-4 space-y-2">
                      <div className="flex items-center gap-2 text-[9px] font-mono uppercase text-gray-500 font-bold">
                        <span>{study.author?.name || 'Research Desk'}</span>
                        <span>•</span>
                        <span>{new Date(study.createdAt).toLocaleDateString(dateLocale.code)}</span>
                      </div>
                      <h3 className="font-serif text-base font-bold leading-snug group-hover:text-brand-800 text-ink-900 transition-colors line-clamp-3">
                        {getStudyTitle(study)}
                      </h3>
                      <p className="text-xs text-gray-600 line-clamp-3 leading-relaxed">
                        {getStudyExcerpt(study)}
                      </p>
                    </div>
                  </div>

                  <div className="p-4 pt-0">
                    <button className="w-full py-2 px-3 text-center text-xs font-bold uppercase bg-white border border-neutral-300 hover:border-brand-800 text-neutral-800 hover:text-white hover:bg-brand-800 rounded transition-all duration-300 flex items-center justify-center gap-1.5 cursor-pointer">
                      <span>{study.isPrivate ? t('premiumStudy') : 'Read Access'}</span>
                      <ChevronRight size={14} className="group-hover:translate-x-1 transition-transform rtl:rotate-180" />
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </section>
      )}

      {/* ADDITIONAL SECTIONS */}
      <section className="w-full max-w-[1024px] mx-auto bg-paper-50 border-t border-brand-800 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 divide-y md:divide-y-0 md:divide-x rtl:divide-x-reverse divide-ink-900/10">
        {['ai', 'food-beverage', 'expo', 'business-statistics'].map((catSlug) => {
          const sectionArticles = articles.filter(a => a.category?.slug === catSlug).slice(0, 3);
          if (sectionArticles.length === 0) return null;
          
          let title = '';
          if (catSlug === 'ai') title = t('ai');
          if (catSlug === 'food-beverage') title = t('foodBeverage');
          if (catSlug === 'expo') title = t('expo');
          if (catSlug === 'business-statistics') title = t('businessStats');
          
          return (
            <div key={catSlug} className="p-6 flex flex-col space-y-4">
              <h3 className="text-[10px] uppercase font-black tracking-widest text-ink-900 border-b-2 border-brand-800 pb-1 w-fit">
                {title}
              </h3>
              {sectionArticles.map((article, i) => (
                <div 
                  key={article.id}
                  onClick={() => setSelectedArticle(article)}
                  className="cursor-pointer group hover:bg-black/[0.02] p-2 -mx-2 rounded transition-all duration-200"
                >
                  <h4 className="font-serif text-sm font-bold leading-tight group-hover:text-brand-800 text-ink-900 transition-colors line-clamp-3">
                    {getTranslation(article)?.title}
                  </h4>
                  <p className="text-[10px] text-gray-500 mt-1 uppercase font-bold opacity-70">
                    {new Date(article.createdAt).toLocaleDateString(dateLocale.code)}
                  </p>
                </div>
              ))}
            </div>
          );
        })}
      </section>

      {/* GORGEOUS IMMERSIVE NEWSPAPER DETAIL OVERLAY MODAL */}
      {selectedArticle && (
        <ArticleModal 
          article={selectedArticle} 
          lang={lang!} 
          onClose={() => setSelectedArticle(null)} 
        />
      )}

      {/* DEEP INTEL STUDY DETAIL OVERLAY MODAL */}
      {selectedStudy && (
        <div 
          className="fixed inset-0 bg-brand-800/85 backdrop-blur-md flex items-center justify-center z-50 p-4 sm:p-6 md:p-8"
          onClick={() => setSelectedStudy(null)}
        >
          <div 
            className="bg-paper-50 border-x border-brand-800 max-w-3xl w-full h-[90vh] overflow-y-auto shadow-2xl flex flex-col relative text-start transition-all duration-300"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Header toolbar */}
            <div className="px-6 py-4 bg-white border-b border-brand-800/10 flex justify-between items-center shrink-0">
              <span className="text-[10px] font-black uppercase text-brand-800 tracking-widest flex items-center gap-1.5">
                <Sparkles size={12} className="text-amber-500 animate-pulse" />
                {selectedStudy.isPrivate ? t('premiumStudy') : 'Open Research Report'}
              </span>
              <button 
                onClick={() => setSelectedStudy(null)}
                className="text-ink-900 hover:text-brand-800 font-black text-xs uppercase tracking-widest border border-brand-800/20 px-3 py-1 hover:border-brand-800 transition-colors cursor-pointer"
              >
                {lang === 'ar' ? '✕ إغلاق' : lang === 'ckb' ? '✕ داخستن' : lang === 'zh' ? '✕ 关闭' : '✕ Close'}
              </button>
            </div>

            {/* Content wrapper */}
            <div className="flex-grow overflow-y-auto">
              <div className="p-6 md:p-12">
                <h1 className="text-3xl md:text-5xl font-serif font-black leading-tight text-center text-ink-900 tracking-tight mb-6">
                  {getStudyTitle(selectedStudy)}
                </h1>

                <div className="flex justify-center items-center gap-3 text-[10px] font-bold uppercase mb-12 opacity-60 text-ink-900 border-y border-double border-brand-800/20 py-2.5">
                  <span>By {selectedStudy.author?.name || 'Senior Fellow'}</span>
                  <span>•</span>
                  <span>
                    {new Date(selectedStudy.createdAt).toLocaleDateString(lang === 'ar' ? 'ar-EG' : lang === 'zh' ? 'zh-CN' : 'en-US', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}
                  </span>
                </div>

                {selectedStudy.imageUrl && (
                  <div className="w-full mb-12 overflow-hidden rounded-xs border border-brand-800/10 relative aspect-video shadow-sm">
                    <img 
                      src={selectedStudy.imageUrl} 
                      alt={getStudyTitle(selectedStudy)} 
                      className="w-full h-full object-cover"
                      referrerPolicy="no-referrer"
                    />
                  </div>
                )}

                {/* DECISION: RENDER STUDY BODY OR THE PREMIUM CONVERSION PAYWALL */}
                {selectedStudy.isPrivate && !isSubscribed ? (
                  /* GORGEOUS PREMIUM PAYWALL WALL */
                  <div className="space-y-8 bg-white border border-amber-200 rounded-lg p-6 md:p-8 shadow-sm">
                    <div className="text-center space-y-3">
                      <div className="mx-auto w-12 h-12 rounded-full bg-amber-50 flex items-center justify-center text-amber-500 border border-amber-200">
                        <Lock size={22} className="animate-pulse" />
                      </div>
                      <h3 className="font-serif text-xl md:text-2xl font-black text-gray-900 tracking-tight">
                        {lang === 'ar' ? 'محتوى حصري للمشتركين المميزين' : lang === 'ckb' ? 'بەرنامەی تایبەت بۆ بەشداربووان' : lang === 'zh' ? '智库付费专享机密报告' : 'Exclusive Premium Research Entry'}
                      </h3>
                      <p className="text-xs text-gray-500 max-w-md mx-auto leading-relaxed">
                        {lang === 'ar' 
                          ? 'هذا التقرير الاستراتيجي المعمق متاح حصرياً لحاملي اشتراكات النخبة والمؤسسات لدى وكالة العراق والصين.' 
                          : lang === 'ckb' 
                          ? 'ئەم ڕاپۆرتە قووڵە ستراتیژییە تەنها بۆ بەشداربووانی نایاب و نێودەوڵەتی بەردەستە.' 
                          : lang === 'zh' 
                          ? '本深度战略分析报告仅供具有活跃订阅权限的 伊拉克-中国通讯社 高级及企业会员阅读。' 
                          : 'This strategic bilateral intelligence dossier is restricted to active premium and enterprise portfolio holders of Iraq - China Agency.'}
                      </p>
                    </div>

                    <div className="border-t border-neutral-100 pt-6 space-y-4">
                      <h4 className="text-[10px] font-mono uppercase font-black text-brand-800 tracking-wider">
                        {lang === 'ar' ? 'الملخص التنفيذي المتاح' : lang === 'ckb' ? 'کورتەی سەرەکی بەردەست' : lang === 'zh' ? '公开摘要' : 'Abstract Overview'}
                      </h4>
                      <p className="text-sm text-gray-700 italic bg-neutral-50 p-4 border-l-4 border-amber-500 leading-relaxed font-serif">
                        {getStudyExcerpt(selectedStudy)}
                      </p>
                    </div>

                    {/* Subscription Pricing Widget Embedded Directly */}
                    <div className="space-y-4 border-t border-neutral-100 pt-6">
                      <div className="text-center">
                        <span className="bg-amber-100 text-amber-900 text-[10px] font-bold px-2.5 py-1 rounded-full uppercase tracking-widest">
                          {t('subscribeToRead')}
                        </span>
                      </div>
                      <SubscriptionCard />
                    </div>
                  </div>
                ) : (
                  /* FULL TEXT MARKDOWN RENDERER */
                  <div 
                    className="prose prose-neutral max-w-none font-serif text-lg leading-relaxed text-gray-800 space-y-6 whitespace-pre-wrap md:px-4"
                    dir={lang === 'ar' || lang === 'ckb' ? 'rtl' : 'ltr'}
                  >
                    <div dangerouslySetInnerHTML={{ __html: DOMPurify.sanitize(getStudyContent(selectedStudy).replace(/\n/g, '<br/>')) }} />
                  </div>
                )}

                {/* RELATED RESEARCH STUDIES SECTION */}
                <div className="mt-12 pt-8 border-t border-double border-brand-800/20 space-y-6">
                  <div className="flex items-center gap-2">
                    <BookOpen size={18} className="text-brand-800" />
                    <h3 className="font-serif text-lg font-black text-ink-900">
                      {lang === 'ar' ? 'الدراسات والبحوث ذات الصلة' : lang === 'ckb' ? 'توێژینەوە پەیوەندیدارەکان' : lang === 'zh' ? '相关专题研究' : 'Related Research Studies'}
                    </h3>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    {studies
                      .filter(s => s.id !== selectedStudy.id)
                      .slice(0, 2)
                      .map((related) => {
                        const isRelatedLocked = related.isPrivate && !isSubscribed;
                        return (
                          <div 
                            key={related.id}
                            onClick={() => setSelectedStudy(related)}
                            className="group cursor-pointer flex gap-3 p-3 bg-white border border-neutral-200 hover:border-brand-800 rounded hover:shadow-sm transition-all duration-300 text-start"
                          >
                            {related.imageUrl && (
                              <div className="w-20 h-20 shrink-0 overflow-hidden rounded relative">
                                <img 
                                  src={related.imageUrl} 
                                  alt={getStudyTitle(related)} 
                                  className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105"
                                  referrerPolicy="no-referrer"
                                />
                                {isRelatedLocked && (
                                  <div className="absolute inset-0 bg-black/40 flex items-center justify-center text-amber-400">
                                    <Lock size={10} />
                                  </div>
                                )}
                              </div>
                            )}
                            <div className="space-y-1">
                              <span className={`text-[8px] font-black uppercase px-1.5 py-0.5 rounded ${related.isPrivate ? 'bg-amber-100 text-amber-800' : 'bg-emerald-100 text-emerald-800'}`}>
                                {related.isPrivate ? 'PREMIUM' : 'OPEN'}
                              </span>
                              <h4 className="font-serif text-xs font-bold leading-tight line-clamp-2 text-ink-900 group-hover:text-brand-800 transition-colors mt-1">
                                {getStudyTitle(related)}
                              </h4>
                            </div>
                          </div>
                        );
                      })}
                  </div>
                </div>

              </div>
            </div>
          </div>
        </div>
      )}

      {/* POLITICAL NEWS SECTION */}
      {articles.filter(a => a.category?.slug === 'politics').length > 0 && (
        <section className="w-full max-w-[1024px] mx-auto bg-white border-t-4 border-brand-800 p-6 md:p-8 mt-12 mb-12">
          <div className="flex justify-between items-baseline border-b border-brand-800/15 pb-3 mb-6">
            <h2 className="font-serif text-2xl md:text-3xl font-black tracking-tight text-ink-900 uppercase flex items-center gap-2">
              <span className="w-3.5 h-3.5 bg-brand-800"></span>
              {lang === 'ar' ? 'الأخبار السياسية' : lang === 'zh' ? '政治新闻' : lang === 'ckb' ? 'هەواڵە سیاسییەکان' : 'Political News'}
            </h2>
            <Link 
              to={`/${lang}/category/politics`} 
              className="text-xs font-black uppercase tracking-widest text-brand-800 hover:underline"
            >
              {lang === 'ar' ? 'عرض المزيد ←' : lang === 'zh' ? '查看更多 →' : lang === 'ckb' ? 'بینینی زیاتر ←' : 'View More →'}
            </Link>
          </div>
          
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4">
            {articles.filter(a => a.category?.slug === 'politics').slice(0, 10).map((article) => {
              const tr = getTranslation(article);
              return (
                <div 
                  key={article.id}
                  onClick={() => setSelectedArticle(article)}
                  className="cursor-pointer group flex flex-col h-full bg-neutral-50/50 hover:bg-neutral-50 border border-neutral-200 transition-all duration-300 rounded overflow-hidden shadow-sm hover:shadow-md"
                >
                  {article.imageUrl ? (
                    <div className="relative w-full aspect-[4/3] overflow-hidden border-b border-neutral-200 shrink-0">
                      <img 
                        src={article.imageUrl} 
                        alt={tr?.title || 'Political News'} 
                        className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                        fetchPriority="low"
                        loading="lazy"
                      />
                    </div>
                  ) : (
                    <div className="w-full aspect-[4/3] bg-brand-800/10 flex items-center justify-center shrink-0">
                      <span className="text-gray-400 font-serif italic text-xs">No Image</span>
                    </div>
                  )}
                  
                  <div className="p-3 flex flex-col flex-grow">
                    <span className="text-[9px] font-mono uppercase tracking-wider text-gray-500 mb-2">
                      {new Date(article.createdAt).toLocaleDateString(dateLocale.code)}
                    </span>
                    <h3 className="font-serif font-bold text-sm leading-snug text-ink-900 group-hover:text-brand-800 transition-colors line-clamp-3">
                      {tr?.title}
                    </h3>
                  </div>
                </div>
              );
            })}
          </div>
        </section>
      )}

      {/* Trending Books Section (Space for 4 trending books on web) */}
      <TrendingBooksSection lang={lang as Locale} />

      {/* Recommended Books Spotlight Section */}
      <RecommendedBooksSection lang={lang as Locale} />

      {/* Bilateral Tourism Showcase Section */}
      <TourismSection lang={lang as Locale} />

      {/* Women Leadership, Rights & Policy Forum */}
      <WomenSection lang={lang as Locale} />

      {/* Invest Iraq Section */}
      <InvestIraq lang={lang as Locale} />

      <VisaFlightSection lang={lang} />

      {/* Contact Us Section */}
      <ContactUs lang={lang as Locale} />

    </main>
   </div>
  );
}
